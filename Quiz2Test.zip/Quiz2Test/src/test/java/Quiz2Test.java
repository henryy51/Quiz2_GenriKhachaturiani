package Commands;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import java.util.List;
import org.testng.annotations.Test;
import java.util.List;


public class Quiz2Test {
    @Test
    public void firstMethod() {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("https://demoqa.com/progress-bar");

        WebElement startButton = driver.findElement(By.id("startStopButton"));
        startButton.click();
        WebElement progressBar = driver.findElement(By.cssSelector("#progressBar > div[role='progressbar']"));

        new WebDriverWait = new WebDriverWait(driver,20);
        wait.until(ExpectedConditions.attributeContains(progressBar,"100"));
        System.out.println("100%");
        driver.quit();


        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("http://webdriveruniversity.com/Dropdown-Checkboxes-RadioButtons/index.html");

        WebElement dropDown = driver.findElement(By.id("dropdown-menu-1"));
        Select dropLanguage = new Select(dropDown);
        dropLanguage.selectByVisibleText("C#");
        String text = dropLanguage.getFirstSelectedOption().getText();
        if(text.equals("C#")){
            System.out.println("Selected programming language "+ text + " matches to C#");
        }else {
            System.out.println("Selected programming language doesn't match " + text);
        }

        List<WebElement> checkBox = driver.findElements(By.cssSelector("#checkboxes input[type=checkbox]"));
        for (WebElement box : checkBox) {
            if (!box.isSelected()) {
                box.click();
            }
        }

        WebElement radioButYell = driver.findElement(By.cssSelector("#radio-buttons > input[type=radio][value=yellow]"));
        radioButYell.click();

        Select fruitDropBox = new Select(driver.findElement(By.id("fruit-selects")));
        List<WebElement> fruitDBx = fruitDropBox.getOptions();

        for (WebElement dBx : fruitDBx) {
            if (dBx.getAttribute("value").equals("orange") && !dBx.isEnabled()) {
                System.out.println(" 'Orange' option in dropdown is disabled");
            }
        }
        driver.quit();
    }
}
    }
}